#!/bin/bash
####################################################################################
# EDP script to post process emon data in linux, generates a bunch of csv's
# prerequisites:
#	Install oracle-java8-installer
#	sudo -E apt-get install ruby jruby
#	sudo -E jruby -S gem install jruby-win32ole <optional>
#####################################################################################

cd $1

# Fix the path for EDP ruby script and processor specific EDP files
EDPRB=<fix-path>/edp.rb
METRICS=<fix-path>/skx-2s.xml
CHART_FORMAT=<fix-path>/chart_format_skx_2s.txt

# fix the path for the EMON input files
EMON_DATA=<fix-emon-files-path>/emon.dat
EMON_V=<fix-emon-files-path>/emon-v.dat
EMON_M=<fix-emon-files-path>/emon-m.dat
OUTPUT=summary.xlsx

CPUS=`grep -c ^processor /proc/cpuinfo`
THREADS=$(( CPUS * 3 / 4 ))
FreeMEM=`free -m | head -2 | tail -1 | awk '{ print $4 }'`
FreeMEM=$(( $FreeMEM - 1024 ))
echo Usable $THREADS threads with $FreeMEM MB memory.

JRUBY_OPTIONS="--server -J-Xmx${FreeMEM}m -J-Xms${FreeMEM}m --1.8"
PARALLELISM=$THREADS


BEGIN=1
END=100000
QPI=6.4

VIEW="--socket-view --thread-view"
#VIEW="--socket-view --core-view --thread-view"
#VIEW=""

#TIMESTAMP_IN_CHART="--timestamp-in-chart"
TIMESTAMP_IN_CHART=""

echo Starting to parallel process the EDP data at `date +"%d-%b-%Y %r"`

#echo "jruby $JRUBY_OPTIONS $EDPRB -i $EMON_DATA -j $EMON_V -k $EMON_M -f $CHART_FORMAT -o $OUTPUT -m $METRICS -b $BEGIN -e $END -q $QPI $VIEW -p $PARALLELISM"
jruby $JRUBY_OPTIONS $EDPRB -i $EMON_DATA -j $EMON_V -k $EMON_M -f $CHART_FORMAT -o $OUTPUT -m $METRICS -b $BEGIN -e $END -q $QPI $VIEW -s 1 -p $PARALLELISM

echo Finished parallel processing the EDP data at `date +"%d-%b-%Y %r"`

exit

